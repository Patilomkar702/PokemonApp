import { Component, Input, OnInit } from '@angular/core';
import { PokemonService } from '../pokemon.service';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit {

  @Input("PokeMonData") pokemon
  url:string
  showDetails:boolean;
  isLoaded:boolean;
  constructor(public pokSer:PokemonService) {
    const doesImageExist = (url) =>
      new Promise((resolve) => {
      const img = new Image();

      img.src = url;
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
    });
   }

  ngOnInit(): void {
    let id=this.getPokemonId(this.pokemon);

    this.pokemon["details"]
    this.url = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
    const doesImageExist = (url) =>
      new Promise((resolve) => {
      const img = new Image();

      img.src = url;
      img.onload = () => resolve(true);
      img.onerror = () => resolve(false);
    });
    doesImageExist(this.url).then((data:boolean)=>{
      this.isLoaded = data;
      if(!this.isLoaded){
        console.log("False : "+ this.url);
      }
    })
  }

  getPokemonId(pokemon){
    return pokemon.url.split("/")[6]
  }

  toogelDetails(){
    this.showDetails=!this.showDetails;
    if(this.showDetails && !this.pokemon["details"]){
      this.pokSer.getPokemonDetails(this.getPokemonId(this.pokemon)).subscribe((data)=>{
        this.pokemon["details"]=data;
        // console.log(this.pokemon);

      })
    }
  }

}
