import { Component } from '@angular/core';
import { PokemonService } from './pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pokemon';
  pokemons = [];

  constructor(pokemonSer:PokemonService){
    pokemonSer.getPokemons(900).subscribe((data:any)=>{
      this.pokemons = data.results;
      // console.log(this.pokemons);
    })
  }
}
