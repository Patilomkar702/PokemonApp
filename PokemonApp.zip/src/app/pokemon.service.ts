import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {

  constructor(public http:HttpClient) { }

  getPokemons(limit:number){
    let url = "https://pokeapi.co/api/v2/pokemon?limit="+limit;
    return this.http.get(url);
  }

  getPokemonDetails(index:number){
    let url = 'https://pokeapi.co/api/v2/pokemon/'+index;
    return this.http.get(url);
  }
}
